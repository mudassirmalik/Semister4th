<?php 

   $server = "localhost";
   $username = "root";
   $password = "";

   $connect_mysql = mysqli_connect($server, $username, $password);

      if($connect_mysql)
      {
      echo "Connection established.";
      }

      else
      {
      die("Unable to connect");
      }

      $db = "recordd";
      $mysql_db = mysqli_select_db($connect_mysql,$db);

      if($mysql_db)
      {
      echo "<BR><BR>Connected to the database.";
      }

      else
      {
      die("Unable to connect to the database");
      }

   $Fname = $_POST['fname'];
   $Lname = $_POST['lname'];
   $Uname = $_POST['uname'];
   $EmailAd = $_POST['emailad'];
   $Gender = $_POST['gender'];
   $Password = $_POST['pass'];
   $CPassword = $_POST['cpass'];      

      $sql_insert = "INSERT INTO storetb (fname,lname,uname,emailad,gender,pass,cpass)
      VALUES ('$Fname','$Lname','$Uname','$EmailAd','$Gender','$Password','$CPassword')";

      $result = mysqli_query($connect_mysql,$sql_insert);
      if($result)
      {
      echo "<BR><BR>The records have been added to the table.";
      }

      else
      {
      echo "Unable to insert records.";
      mysqli_error();
      }
 ?>