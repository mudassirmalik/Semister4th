<?php 

   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASSWORD' ,'');
   define('DB_NAME', 'record');

   mysql_connect(DB_HOST,DB_USER,DB_PASSWORD);
   mysql_select_db(DB_NAME) or die(mysql_error());

   $Fname = $_POST['fname'];
   $Lname = $_POST['lname'];
   $Uname = $_POST['uname'];
   $EmailAd = $_POST['emailad'];
   $Gender = $_POST['gender'];
   $Password = $_POST['pass'];
   $CPassword = $_POST['cpass'];

   mysql_query("INSERT into storetb (fname,lname,uname,emailad,gender,pass,cpass) values ('$Fname','$Lname','$Uname','$EmailAd','$Gender','$Password','$CPassword')");

   header('location:index.php');

 ?>