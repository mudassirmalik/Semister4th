/*
Navicat MySQL Data Transfer

Source Server         : xampp
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : record

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2019-01-12 17:42:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `storetb`
-- ----------------------------
DROP TABLE IF EXISTS `storetb`;
CREATE TABLE `storetb` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Fname` varchar(30) DEFAULT NULL,
  `Lname` varchar(30) DEFAULT NULL,
  `Uname` varchar(30) DEFAULT NULL,
  `EmailAd` varchar(30) DEFAULT NULL,
  `Gender` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  `CPassword` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of storetb
-- ----------------------------
