<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>SignUP</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="icon" href="images/bg-01.jpg">
		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>

		<div class="wrapper" style="background-image: url('images/ubuntu_gloss_by_sworiginal.png');">
			<div class="inner">
				<div class="image-holder">
					<img src="images/bg-01.jpg" alt="">
				</div>
				<!-- Start Form -->
				<form action="add.php" method="post">
					<h3>SignUp Form</h3>
					<!-- <div class="form-group">
						<input type="text" class="form-control" name="id">
					</div> -->
					<div class="form-group">
						<input type="text" placeholder="First Name" class="form-control" name="fname">
						<input type="text" placeholder="Last Name" class="form-control" name="lname">
					</div>
					<div class="form-wrapper">
						<input type="text" placeholder="Username" class="form-control" name="uname">
						<i class="zmdi zmdi-account"></i>
					</div>
					<div class="form-wrapper">
						<input type="email" placeholder="Email Address" class="form-control" name="emailad">
						<i class="zmdi zmdi-email"></i>
					</div>
					<div class="form-wrapper">
						<select name="gender" id="" class="form-control">
							<option value="" disabled selected>Gender</option>
							<option value="male">Male</option>
							<option value="femal">Female</option>
							<option value="other">Other</option>
						</select>
						<i class="zmdi zmdi-caret-down" style="font-size: 17px"></i>
					</div>
					<div class="form-wrapper">
						<input type="password" placeholder="Password" class="form-control" name="pass">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<div class="form-wrapper">
						<input type="password" placeholder="Confirm Password" class="form-control" name="cpass">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<input type="submit" name="" value="">
						<!-- <i class="zmdi zmdi-arrow-right"></i> -->
				</form>
				<!-- End Form -->
			</div>
		</div>
		
	</body>
</html>