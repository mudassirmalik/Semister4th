<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<form action="insert.php" method="post">
		<input type="text" name="user_id"  placeholder="Id">
		<input type="text" name="user_name"  placeholder="Name">
		<input type="email" name="user_email_id" placeholder="Email">
		<input type="submit" name="" >
	</form>
</body>
</html>