<?php
$server = "";
$username = "root";
$password = "";
$connect_mysql = mysql_connect($server, $username, $password);
if($connect_mysql)
{
echo "Connection established.";
}
else
{
die("Unable to connect");
}
$db = "user";
$mysql_db = mysql_select_db($db);
if($mysql_db)
{
echo "<BR><BR>Connected to the database.";
}
else
{
die("Unable to connect to the database");
}

$user_id = $_POST ['user_id'];
$user_name = $_POST ['user_name'];
$user_email_id = $_POST ['user_email_id'];

$sql_insert = "INSERT INTO user_contact (user_id, user_name, user_email_id)
VALUES ('$user_id','$user_name','$user_email_id')";
$result = mysql_query($sql_insert);
if($result)
{
echo "<BR><BR>The records have been added to the table.";
}
else
{
echo "Unable to insert records.";
mysql_error();
}
?>